import { Lock, ShieldCheck, BadgeCheck } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full mt-8 pb-6 px-4 flex flex-col items-center gap-3">
      <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-emerald-400" />
          Site certifié SSL
        </span>
        <span className="text-border">|</span>
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Protégé par Replit Security
        </span>
        <span className="text-border">|</span>
        <span className="flex items-center gap-1.5">
          <BadgeCheck className="w-3.5 h-3.5 text-emerald-400" />
          Partenaire Officiel Booking.com &amp; Go Voyages
        </span>
      </div>
      <p className="text-xs text-muted-foreground/60 text-center">
        Destination Sûre © 2026 — Tous droits réservés. Connexion cryptée de bout en bout.
      </p>
    </footer>
  );
}
