export interface Destination {
  id: string;
  name: string;
  country: string;
  description: string;
  ambiance: "Nature" | "Ville" | "Plage";
  weather: {
    temp: number;
    condition: string;
    humidity: number;
  };
  gradient: string;
}

// ── City pools ───────────────────────────────────────────────────────────────

const PLAGE_CITIES: { city: string; country: string }[] = [
  { city: "Ibiza", country: "Espagne" },
  { city: "Mykonos", country: "Grèce" },
  { city: "Palma de Majorque", country: "Espagne" },
  { city: "Rio de Janeiro", country: "Brésil" },
  { city: "Maldives", country: "Maldives" },
  { city: "Seychelles", country: "Seychelles" },
  { city: "Dubaï", country: "Émirats Arabes Unis" },
  { city: "Los Angeles", country: "États-Unis" },
  { city: "Saint-Tropez", country: "France" },
  { city: "Honolulu", country: "États-Unis" },
  { city: "Cancún", country: "Mexique" },
  { city: "Costa del Sol", country: "Espagne" },
  { city: "Sardaigne", country: "Italie" },
  { city: "Sicile", country: "Italie" },
  { city: "Île Maurice", country: "Maurice" },
  { city: "Barcelone", country: "Espagne" },
  { city: "Nice", country: "France" },
  { city: "Lisbonne", country: "Portugal" },
  { city: "Bali", country: "Indonésie" },
  { city: "Miami", country: "États-Unis" },
  { city: "Phuket", country: "Thaïlande" },
  { city: "Tulum", country: "Mexique" },
  { city: "Koh Samui", country: "Thaïlande" },
  { city: "Dubrovnik", country: "Croatie" },
  { city: "Zanzibar", country: "Tanzanie" },
  { city: "Cap-Vert", country: "Cap-Vert" },
  { city: "La Réunion", country: "France" },
  { city: "Martinique", country: "France" },
  { city: "Biarritz", country: "France" },
  { city: "Algarve", country: "Portugal" },
];

const VILLE_CITIES: { city: string; country: string }[] = [
  { city: "New York", country: "États-Unis" },
  { city: "Tokyo", country: "Japon" },
  { city: "Paris", country: "France" },
  { city: "Londres", country: "Angleterre" },
  { city: "Rome", country: "Italie" },
  { city: "Séoul", country: "Corée du Sud" },
  { city: "Bangkok", country: "Thaïlande" },
  { city: "Singapour", country: "Singapour" },
  { city: "Istanbul", country: "Turquie" },
  { city: "Berlin", country: "Allemagne" },
  { city: "Madrid", country: "Espagne" },
  { city: "Milan", country: "Italie" },
  { city: "Marrakech", country: "Maroc" },
  { city: "Sydney", country: "Australie" },
  { city: "Las Vegas", country: "États-Unis" },
  { city: "Venise", country: "Italie" },
  { city: "Florence", country: "Italie" },
  { city: "Amsterdam", country: "Pays-Bas" },
  { city: "Prague", country: "République Tchèque" },
  { city: "Vienne", country: "Autriche" },
  { city: "Budapest", country: "Hongrie" },
  { city: "Hong Kong", country: "Hong Kong" },
  { city: "Chicago", country: "États-Unis" },
  { city: "Mexico", country: "Mexique" },
  { city: "Buenos Aires", country: "Argentine" },
  { city: "Montréal", country: "Canada" },
  { city: "Melbourne", country: "Australie" },
  { city: "Copenhague", country: "Danemark" },
  { city: "Stockholm", country: "Suède" },
  { city: "Lisbonne", country: "Portugal" },
];

const NATURE_CITIES: { city: string; country: string }[] = [
  { city: "Parcs de l'Ouest Américain", country: "États-Unis" },
  { city: "Fjords de Norvège", country: "Norvège" },
  { city: "Le Cap", country: "Afrique du Sud" },
  { city: "Alpes Suisses", country: "Suisse" },
  { city: "Costa Rica", country: "Costa Rica" },
  { city: "Islande", country: "Islande" },
  { city: "Nouvelle-Zélande", country: "Nouvelle-Zélande" },
  { city: "Polynésie Française", country: "France" },
  { city: "Les Açores", country: "Portugal" },
  { city: "Chamonix", country: "France" },
  { city: "Patagonie", country: "Argentine" },
  { city: "Banff", country: "Canada" },
  { city: "Queenstown", country: "Nouvelle-Zélande" },
  { city: "Serengeti", country: "Tanzanie" },
  { city: "Galápagos", country: "Équateur" },
  { city: "Himalaya", country: "Népal" },
  { city: "Laponie", country: "Finlande" },
  { city: "Lofoten", country: "Norvège" },
  { city: "Îles Féroé", country: "Danemark" },
  { city: "Dolomites", country: "Italie" },
  { city: "Cappadoce", country: "Turquie" },
  { city: "Sahara Marocain", country: "Maroc" },
  { city: "Madagascar", country: "Madagascar" },
  { city: "Sri Lanka", country: "Sri Lanka" },
  { city: "Vancouver", country: "Canada" },
  { city: "Parc Plitvice", country: "Croatie" },
  { city: "Écosse", country: "Écosse" },
  { city: "Bornéo", country: "Malaisie" },
  { city: "Amazonie", country: "Brésil" },
  { city: "Interlaken", country: "Suisse" },
];

// ── Description templates ────────────────────────────────────────────────────

const PLAGE_TEMPLATES = [
  "À {city}, les vagues viennent embrasser des plages de sable fin sous un soleil ardent et implacable.",
  "Des eaux turquoise, un ciel sans nuage — {city} vous promet une parenthèse balnéaire inoubliable.",
  "{city} dévoile ses criques secrètes, ses couchers de soleil flamboyants et une atmosphère festive unique.",
  "Entre coraux multicolores et palmiers ondulants, {city} est une ode vivante à la douceur tropicale.",
  "La mer, le sable, et l'infini de l'horizon — {city} vous offre l'évasion absolue au bord de l'eau.",
  "{city} brille comme un joyau maritime — plages dorées, cocktails au coucher du soleil et nuits étoilées.",
  "Nichée entre mer et ciel, {city} incarne le rêve balnéaire dans toute sa splendeur solaire.",
  "Fêtes électriques, couchers de soleil à couper le souffle et eaux cristallines — {city} ne déçoit jamais.",
  "{city}, c'est l'endroit où le monde entier vient oublier ses soucis, pieds dans le sable.",
  "De l'aube dorée au crépuscule écarlate, {city} vous enveloppe dans une lumière méditerranéenne irrésistible.",
];

const VILLE_TEMPLATES = [
  "{city} — une métropole envoûtante où chaque rue raconte des siècles d'histoire, d'art et de passion humaine.",
  "Dans les artères animées de {city}, la vie pulse à un rythme électrique, mêlant tradition et modernité.",
  "{city} vous ouvre les bras : musées de classe mondiale, gastronomie sublime et une âme urbaine incomparable.",
  "Flâner à {city}, c'est se laisser emporter par une énergie unique, faite de rencontres et de découvertes inattendues.",
  "Capitale du style, du goût et de l'élégance, {city} est une ville qui ne finit jamais de vous surprendre.",
  "{city} vibre jour et nuit — marchés colorés, skyline vertigineux et une vie nocturne légendaire.",
  "L'architecture de {city} est un livre ouvert sur l'histoire du monde, à chaque coin de rue une nouvelle page.",
  "{city} est un kaléidoscope culturel : expositions, concerts, saveurs et visages venus des quatre coins du globe.",
  "On dit que {city} change les gens. Ceux qui y vont ne reviennent jamais tout à fait pareils.",
  "Gastronomie, mode, musées et cafés bohèmes — {city} rassemble tout ce qui rend la vie belle.",
];

const NATURE_TEMPLATES = [
  "À {city}, la nature reprend ses droits avec une majesté silencieuse qui coupe le souffle à chaque instant.",
  "{city} est un sanctuaire de grands espaces, où l'air pur et la lumière rasante transforment chaque balade en poème.",
  "Entre pics enneigés et forêts millénaires, {city} révèle une beauté sauvage et préservée, loin du tumulte du monde.",
  "Seul face à l'immensité de {city}, vous comprendrez pourquoi certains endroits restent à jamais gravés dans la mémoire.",
  "{city} vous invite à disparaître dans sa nature intacte — cascades, faune sauvage et horizons infinis vous attendent.",
  "Le silence de {city} est celui des grandes choses : forêts denses, rivières limpides et ciel étoilé sans limite.",
  "Explorer {city}, c'est renouer avec l'essentiel — la terre, le vent, et la beauté brute d'un monde encore intact.",
  "À {city}, chaque sentier mène à une découverte, chaque aurore est un spectacle, et la nature parle à voix haute.",
  "{city} est l'un de ces rares endroits sur Terre où l'on réalise à quel point le monde est vaste et magnifique.",
  "Volcans, glaciers, jungle dense ou plaines infinies — {city} concentre des paysages d'une diversité à couper le souffle.",
];

// ── Weather generators ───────────────────────────────────────────────────────

const PLAGE_CONDITIONS = ["Ensoleillé", "Ensoleillé", "Ensoleillé", "Légèrement voilé", "Ensoleillé"];
const VILLE_CONDITIONS = ["Partiellement nuageux", "Clair", "Ensoleillé", "Nuageux", "Partiellement nuageux", "Clair"];
const NATURE_CONDITIONS = ["Clair", "Partiellement nuageux", "Nuageux", "Ensoleillé", "Venteux", "Clair"];

const PLAGE_GRADIENTS = [
  "from-amber-400 to-rose-500",
  "from-sky-400 to-blue-600",
  "from-cyan-400 to-teal-600",
  "from-yellow-400 to-orange-500",
  "from-pink-400 to-orange-500",
  "from-teal-400 to-cyan-600",
  "from-green-400 to-teal-600",
  "from-rose-400 to-pink-500",
];

const VILLE_GRADIENTS = [
  "from-rose-400 to-pink-600",
  "from-orange-400 to-red-600",
  "from-slate-500 to-gray-700",
  "from-blue-400 to-indigo-600",
  "from-zinc-500 to-slate-800",
  "from-fuchsia-500 to-violet-700",
  "from-yellow-500 to-amber-700",
  "from-pink-500 to-rose-700",
  "from-indigo-500 to-purple-700",
];

const NATURE_GRADIENTS = [
  "from-emerald-400 to-teal-700",
  "from-slate-700 to-blue-900",
  "from-green-500 to-emerald-800",
  "from-sky-600 to-green-700",
  "from-lime-500 to-green-700",
  "from-blue-300 to-slate-600",
  "from-stone-600 to-zinc-800",
  "from-teal-600 to-green-900",
];

// ── Utility ──────────────────────────────────────────────────────────────────

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ── Public generator ─────────────────────────────────────────────────────────

export function generateDestination(ambiance: "Nature" | "Ville" | "Plage"): Destination {
  let cityPool: { city: string; country: string }[];
  let templates: string[];
  let conditions: string[];
  let gradients: string[];
  let tempRange: [number, number];
  let humidityRange: [number, number];

  if (ambiance === "Plage") {
    cityPool = PLAGE_CITIES;
    templates = PLAGE_TEMPLATES;
    conditions = PLAGE_CONDITIONS;
    gradients = PLAGE_GRADIENTS;
    tempRange = [22, 34];
    humidityRange = [55, 82];
  } else if (ambiance === "Ville") {
    cityPool = VILLE_CITIES;
    templates = VILLE_TEMPLATES;
    conditions = VILLE_CONDITIONS;
    gradients = VILLE_GRADIENTS;
    tempRange = [12, 28];
    humidityRange = [50, 75];
  } else {
    cityPool = NATURE_CITIES;
    templates = NATURE_TEMPLATES;
    conditions = NATURE_CONDITIONS;
    gradients = NATURE_GRADIENTS;
    tempRange = [5, 22];
    humidityRange = [48, 82];
  }

  const { city, country } = pick(cityPool);
  const template = pick(templates);

  return {
    id: city.toLowerCase().replace(/\s+/g, "-"),
    name: city,
    country,
    description: template.replace(/\{city\}/g, city),
    ambiance,
    weather: {
      temp: randInt(...tempRange),
      condition: pick(conditions),
      humidity: randInt(...humidityRange),
    },
    gradient: pick(gradients),
  };
}
