import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Compass } from "lucide-react";
import { useTrip } from "@/context/TripContext";

const messages = [
  "Analyse de vos préférences...",
  "Consultation des destinations secrètes...",
  "Vérification des disponibilités...",
  "Optimisation de votre surprise...",
  "Destination trouvée ! Préparation de votre enveloppe mystère..."
];

export default function Recherche() {
  const [, setLocation] = useLocation();
  const { selectedDestination } = useTrip();
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    if (!selectedDestination) {
      setLocation("/");
      return;
    }

    const messageInterval = setInterval(() => {
      setMessageIndex(prev => Math.min(prev + 1, messages.length - 1));
    }, 1000); // cycle messages every 1 second

    const finishTimeout = setTimeout(() => {
      setLocation("/resultat");
    }, 5500); // Move to resultat after 5.5s

    return () => {
      clearInterval(messageInterval);
      clearTimeout(finishTimeout);
    };
  }, [selectedDestination, setLocation]);

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col items-center justify-center p-6 overflow-hidden relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(234,179,8,0.05),transparent_50%)]" />
      
      <div className="relative z-10 flex flex-col items-center max-w-md w-full">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="relative w-32 h-32 mb-12 flex items-center justify-center"
        >
          <div className="absolute inset-0 rounded-full border-2 border-primary/20 border-t-primary animate-spin" style={{ animationDuration: '3s' }} />
          <div className="absolute inset-2 rounded-full border-2 border-primary/10 border-b-primary animate-spin" style={{ animationDuration: '2s', animationDirection: 'reverse' }} />
          <Compass className="w-12 h-12 text-primary absolute" />
          
          <motion.div 
            className="absolute inset-0 rounded-full bg-primary/10 blur-xl"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>

        <div className="h-16 flex items-center justify-center text-center">
          <AnimatePresence mode="wait">
            <motion.p
              key={messageIndex}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="text-xl md:text-2xl font-serif text-white/90"
              data-testid="text-suspense-message"
            >
              {messages[messageIndex]}
            </motion.p>
          </AnimatePresence>
        </div>

        <motion.div 
          className="w-full h-1 bg-border rounded-full mt-12 overflow-hidden"
        >
          <motion.div 
            className="h-full bg-primary"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 5.5, ease: "linear" }}
          />
        </motion.div>
      </div>
    </div>
  );
}