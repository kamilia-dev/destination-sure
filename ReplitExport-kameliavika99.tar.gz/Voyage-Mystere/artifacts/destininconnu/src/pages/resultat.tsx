import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Lock, MapPin, CloudSun, CalendarClock, Plane, Train, Sparkles, RefreshCcw } from "lucide-react";
import { useTrip } from "@/context/TripContext";
import { Button } from "@/components/ui/button";
import Footer from "@/components/Footer";

export default function Resultat() {
  const [, setLocation] = useLocation();
  const { formData, selectedDestination, setFormData, setSelectedDestination } = useTrip();
  const [revealed, setRevealed] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ days: 2, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    if (!selectedDestination) {
      setLocation("/");
      return;
    }

    // Fake countdown to 48h from now
    const targetDate = new Date().getTime() + 48 * 60 * 60 * 1000;
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;
      
      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedDestination, setLocation]);

  if (!selectedDestination) return null;

  const handleRestart = () => {
    setFormData({ budget: 1000, dateRange: undefined, transport: null, ambiance: null });
    setSelectedDestination(null);
    setLocation("/");
  };

  const transportIcon = formData.transport === "Train" ? <Train className="w-5 h-5" /> : <Plane className="w-5 h-5" />;

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col items-center justify-center p-4 md:p-8 overflow-hidden relative">
      <AnimatePresence>
        {revealed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15 }}
            className={`absolute inset-0 bg-gradient-to-br ${selectedDestination.gradient}`}
          />
        )}
      </AnimatePresence>

      <motion.div 
        className="w-full max-w-xl z-10"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="bg-card/80 backdrop-blur-xl border border-border rounded-3xl overflow-hidden shadow-2xl relative">
          
          {/* Header Area */}
          <div className="h-64 relative flex items-center justify-center overflow-hidden bg-muted">
            <AnimatePresence mode="wait">
              {!revealed ? (
                <motion.div
                  key="locked-bg"
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1000')] bg-cover bg-center opacity-30 blur-md grayscale"
                />
              ) : (
                <motion.div
                  key="revealed-bg"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1.5 }}
                  className={`absolute inset-0 bg-gradient-to-br ${selectedDestination.gradient} opacity-40`}
                />
              )}
            </AnimatePresence>

            <div className="z-10 text-center relative">
              <AnimatePresence mode="wait">
                {!revealed ? (
                  <motion.div key="locked-content" exit={{ scale: 1.5, opacity: 0 }} transition={{ duration: 0.5 }}>
                    <Lock className="w-12 h-12 text-primary mx-auto mb-4" />
                    <h2 className="text-4xl font-serif tracking-widest text-white/50 blur-[2px] select-none">??????????</h2>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="revealed-content"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                  >
                    <MapPin className="w-10 h-10 text-primary mx-auto mb-2" />
                    <h2 className="text-5xl md:text-6xl font-serif text-white tracking-tight" data-testid="text-destination-name">{selectedDestination.name}</h2>
                    <p className="text-xl text-primary font-light tracking-widest uppercase mt-2">{selectedDestination.country}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Details Area */}
          <div className="p-6 md:p-8 space-y-6">
            {!revealed ? (
              <motion.div className="space-y-6" exit={{ opacity: 0 }}>
                <div className="bg-background/50 rounded-xl p-4 flex items-center justify-between border border-border/50">
                  <div className="flex items-center gap-3">
                    <CloudSun className="w-6 h-6 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Météo à destination</p>
                      <p className="font-medium text-white">{selectedDestination.weather.temp}°C • {selectedDestination.weather.condition}</p>
                    </div>
                  </div>
                </div>

                <div className="text-center space-y-3">
                  <p className="text-sm text-muted-foreground uppercase tracking-widest">Révélation dans</p>
                  <div className="flex justify-center gap-4 font-mono text-2xl text-white">
                    <div className="flex flex-col"><span className="text-primary">{String(timeLeft.days).padStart(2, '0')}</span><span className="text-xs text-muted-foreground uppercase">Jours</span></div>
                    <span>:</span>
                    <div className="flex flex-col"><span className="text-primary">{String(timeLeft.hours).padStart(2, '0')}</span><span className="text-xs text-muted-foreground uppercase">Hres</span></div>
                    <span>:</span>
                    <div className="flex flex-col"><span className="text-primary">{String(timeLeft.minutes).padStart(2, '0')}</span><span className="text-xs text-muted-foreground uppercase">Min</span></div>
                    <span>:</span>
                    <div className="flex flex-col"><span className="text-primary">{String(timeLeft.seconds).padStart(2, '0')}</span><span className="text-xs text-muted-foreground uppercase">Sec</span></div>
                  </div>
                </div>

                <Button 
                  onClick={() => setRevealed(true)}
                  className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-primary-foreground font-serif tracking-wide shadow-[0_0_20px_rgba(234,179,8,0.2)] hover:shadow-[0_0_40px_rgba(234,179,8,0.5)] transition-all group"
                  data-testid="btn-reveal"
                >
                  Révéler ma destination <Sparkles className="ml-2 w-5 h-5 group-hover:animate-pulse" />
                </Button>
              </motion.div>
            ) : (
              <motion.div 
                className="space-y-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <p className="text-center text-lg text-white/80 font-light italic leading-relaxed" data-testid="text-description">
                  "{selectedDestination.description}"
                </p>

                <div className="bg-background/80 rounded-xl p-5 border border-border space-y-4">
                  <div className="flex items-center justify-between border-b border-border/50 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        {transportIcon}
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Départ</p>
                        <p className="font-semibold text-white">Paris</p>
                      </div>
                    </div>
                    <div className="flex-1 px-4 flex items-center">
                      <div className="h-[2px] w-full bg-border relative">
                        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary" />
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Arrivée</p>
                      <p className="font-semibold text-white">{selectedDestination.name}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 pt-2">
                    <CalendarClock className="w-5 h-5 text-primary" />
                    <p className="text-sm text-white/90">
                      Du {formData.dateRange?.from ? format(formData.dateRange.from, "dd MMMM yyyy", { locale: fr }) : "..."} au {formData.dateRange?.to ? format(formData.dateRange.to, "dd MMMM yyyy", { locale: fr }) : "..."}
                    </p>
                  </div>
                </div>

                {/* ============================================================
                  LIENS D'AFFILIATION — À remplacer par vos liens personnalisés
                  ============================================================
                  Remplacez chaque valeur `href` ci-dessous par votre lien
                  d'affiliation fourni par le programme partenaire.

                  Exemple Booking.com :
                    https://www.booking.com/index.html?aid=VOTRE_ID_AFFILIATION

                  Exemple Go Voyages :
                    https://www.govoyages.com/?utm_source=VOTRE_SOURCE&utm_medium=affiliation

                  Exemple SNCF Connect :
                    https://www.sncf-connect.com/?utm_source=VOTRE_SOURCE
                  ============================================================ */}
                <div className="space-y-3 pt-4">
                  {/* LIEN AFFILIATION HÔTELS — Travelpayouts / Hotellook (marker: 535536) */}
                  <a
                    href={`https://search.hotellook.com/?marker=535536&destination=${encodeURIComponent(selectedDestination.name)}&language=fr`}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="btn-booking-hotel"
                    className="flex items-center justify-center gap-3 w-full h-12 rounded-md bg-[#003580] hover:bg-[#00256b] text-white font-medium transition-colors text-sm"
                  >
                    <span className="text-base">🏨</span> Réserver l'hôtel sur Booking.com
                  </a>
                  {/* LIEN AFFILIATION VOLS — Travelpayouts / Jetradar (marker: 535536) */}
                  <a
                    href={`https://www.jetradar.fr/?marker=535536&origin_name=Paris&destination_name=${encodeURIComponent(selectedDestination.name)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="btn-govoyages-flight"
                    className="flex items-center justify-center gap-3 w-full h-12 rounded-md bg-[#e2001a] hover:bg-[#c00016] text-white font-medium transition-colors text-sm"
                  >
                    <span className="text-base">✈️</span> Réserver le vol sur Go Voyages
                  </a>
                  {/* LIEN AFFILIATION TRAIN — SNCF Connect (lien direct, pas encore sur Travelpayouts) */}
                  <a
                    href={`https://www.sncf-connect.com/app/trips/search?originLabel=Paris&destinationLabel=${encodeURIComponent(selectedDestination.name)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="btn-sncf-train"
                    className="flex items-center justify-center gap-3 w-full h-12 rounded-md bg-[#8f1c6e] hover:bg-[#7a1860] text-white font-medium transition-colors text-sm"
                  >
                    <span className="text-base">🚄</span> Réserver le train sur SNCF Connect
                  </a>

                  <div className="flex items-center justify-center gap-2 pt-1 text-emerald-400 text-xs font-medium">
                    <Lock className="w-3.5 h-3.5" />
                    <span>Réservation 100% sécurisée et certifiée via nos partenaires officiels.</span>
                  </div>
                </div>

                <Button 
                  variant="outline" 
                  className="w-full h-11 border-border text-white hover:bg-white/5 mt-2"
                  onClick={handleRestart}
                  data-testid="btn-restart"
                >
                  <RefreshCcw className="mr-2 w-4 h-4" /> Recommencer
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>
      <Footer />
    </div>
  );
}