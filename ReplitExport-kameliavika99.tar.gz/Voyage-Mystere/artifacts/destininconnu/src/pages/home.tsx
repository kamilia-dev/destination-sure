import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { motion } from "framer-motion";
import { CalendarIcon, MapIcon, Plane, Train, TreePine, Building, Umbrella } from "lucide-react";
import { addDays, format } from "date-fns";
import { fr } from "date-fns/locale";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { useTrip } from "@/context/TripContext";
import { generateDestination } from "@/data/destinations";
import Footer from "@/components/Footer";

const formSchema = z.object({
  dateRange: z.object({
    from: z.date({ required_error: "Veuillez sélectionner une date de départ." }),
    to: z.date().optional(),
  }, { required_error: "Dates requises." }),
  budget: z.number().min(100).max(3000),
  transport: z.enum(["Train", "Avion"], { required_error: "Choisissez un transport." }),
  ambiance: z.enum(["Nature", "Ville", "Plage"], { required_error: "Choisissez une ambiance." }),
});

export default function Home() {
  const [, setLocation] = useLocation();
  const { setFormData, setSelectedDestination } = useTrip();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      budget: 1000,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setFormData({
      dateRange: values.dateRange,
      budget: values.budget,
      transport: values.transport,
      ambiance: values.ambiance,
    });
    
    const randomDest = generateDestination(values.ambiance);
    setSelectedDestination(randomDest);
    setLocation("/recherche");
  }

  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Cinematic background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="max-w-2xl w-full z-10 space-y-8"
      >
        <div className="text-center space-y-3">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-primary/20 shadow-[0_0_30px_rgba(234,179,8,0.15)]"
          >
            <MapIcon className="w-8 h-8 text-primary" />
          </motion.div>
          <h1 className="text-4xl md:text-5xl font-serif text-white tracking-tight">Destination Sûre</h1>
          <p className="text-muted-foreground text-lg font-light tracking-wide">Osez l'aventure. Nous choisissons la destination, vous vivez la surprise.</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 bg-card/50 backdrop-blur-xl p-8 rounded-2xl border border-border shadow-2xl">
            
            {/* Dates */}
            <FormField
              control={form.control}
              name="dateRange"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel className="text-white/80">Quand souhaitez-vous partir ?</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        id="date"
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal bg-background/50 border-border hover:bg-background/80 hover:text-white",
                          !field.value && "text-muted-foreground"
                        )}
                        data-testid="input-dates"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                        {field.value?.from ? (
                          field.value.to ? (
                            <>
                              {format(field.value.from, "dd LLL yyyy", { locale: fr })} -{" "}
                              {format(field.value.to, "dd LLL yyyy", { locale: fr })}
                            </>
                          ) : (
                            format(field.value.from, "dd LLL yyyy", { locale: fr })
                          )
                        ) : (
                          <span>Sélectionnez vos dates</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                      <Calendar
                        initialFocus
                        mode="range"
                        defaultMonth={field.value?.from}
                        selected={field.value}
                        onSelect={field.onChange}
                        numberOfMonths={2}
                        locale={fr}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage className="text-destructive/80" />
                </FormItem>
              )}
            />

            {/* Budget */}
            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between items-center mb-4">
                    <FormLabel className="text-white/80">Budget maximum</FormLabel>
                    <span className="text-xl font-serif text-primary" data-testid="text-budget-value">{field.value} €</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={100}
                      max={3000}
                      step={50}
                      defaultValue={[field.value]}
                      onValueChange={(vals) => field.onChange(vals[0])}
                      className="py-4"
                      data-testid="slider-budget"
                    />
                  </FormControl>
                  <FormMessage className="text-destructive/80" />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Transport */}
              <FormField
                control={form.control}
                name="transport"
                render={({ field }) => (
                  <FormItem className="space-y-4">
                    <FormLabel className="text-white/80">Mode de transport</FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 gap-3">
                        <TransportCard
                          icon={<Train className="w-6 h-6" />}
                          label="Train"
                          selected={field.value === "Train"}
                          onClick={() => field.onChange("Train")}
                          testId="btn-transport-train"
                        />
                        <TransportCard
                          icon={<Plane className="w-6 h-6" />}
                          label="Avion"
                          selected={field.value === "Avion"}
                          onClick={() => field.onChange("Avion")}
                          testId="btn-transport-avion"
                        />
                      </div>
                    </FormControl>
                    <FormMessage className="text-destructive/80" />
                  </FormItem>
                )}
              />

              {/* Ambiance */}
              <FormField
                control={form.control}
                name="ambiance"
                render={({ field }) => (
                  <FormItem className="space-y-4">
                    <FormLabel className="text-white/80">Ambiance recherchée</FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-3 gap-3">
                        <AmbianceCard
                          icon={<TreePine className="w-5 h-5" />}
                          label="Nature"
                          selected={field.value === "Nature"}
                          onClick={() => field.onChange("Nature")}
                          testId="btn-ambiance-nature"
                        />
                        <AmbianceCard
                          icon={<Building className="w-5 h-5" />}
                          label="Ville"
                          selected={field.value === "Ville"}
                          onClick={() => field.onChange("Ville")}
                          testId="btn-ambiance-ville"
                        />
                        <AmbianceCard
                          icon={<Umbrella className="w-5 h-5" />}
                          label="Plage"
                          selected={field.value === "Plage"}
                          onClick={() => field.onChange("Plage")}
                          testId="btn-ambiance-plage"
                        />
                      </div>
                    </FormControl>
                    <FormMessage className="text-destructive/80" />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-primary-foreground font-serif tracking-wide shadow-[0_0_20px_rgba(234,179,8,0.2)] hover:shadow-[0_0_30px_rgba(234,179,8,0.4)] transition-all"
              data-testid="btn-submit-form"
            >
              Découvrir ma destination mystère →
            </Button>
          </form>
        </Form>
      </motion.div>
      <Footer />
    </div>
  );
}

function TransportCard({ icon, label, selected, onClick, testId }: { icon: React.ReactNode, label: string, selected: boolean, onClick: () => void, testId: string }) {
  return (
    <div
      onClick={onClick}
      data-testid={testId}
      className={cn(
        "cursor-pointer flex flex-col items-center justify-center p-4 rounded-xl border transition-all duration-300",
        selected 
          ? "bg-primary/10 border-primary text-primary shadow-[0_0_15px_rgba(234,179,8,0.1)]" 
          : "bg-background border-border text-muted-foreground hover:border-primary/50 hover:bg-background/80"
      )}
    >
      <div className="mb-2">{icon}</div>
      <span className="font-medium">{label}</span>
    </div>
  );
}

function AmbianceCard({ icon, label, selected, onClick, testId }: { icon: React.ReactNode, label: string, selected: boolean, onClick: () => void, testId: string }) {
  return (
    <div
      onClick={onClick}
      data-testid={testId}
      className={cn(
        "cursor-pointer flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-300",
        selected 
          ? "bg-primary/10 border-primary text-primary shadow-[0_0_15px_rgba(234,179,8,0.1)]" 
          : "bg-background border-border text-muted-foreground hover:border-primary/50 hover:bg-background/80"
      )}
    >
      <div className="mb-2">{icon}</div>
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}