import React, { createContext, useContext, useState, ReactNode } from "react";
import { Destination } from "../data/destinations";
import { DateRange } from "react-day-picker";

export interface TripFormData {
  dateRange: DateRange | undefined;
  budget: number;
  transport: "Train" | "Avion" | null;
  ambiance: "Nature" | "Ville" | "Plage" | null;
}

interface TripContextType {
  formData: TripFormData;
  setFormData: (data: TripFormData) => void;
  selectedDestination: Destination | null;
  setSelectedDestination: (dest: Destination | null) => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export function TripProvider({ children }: { children: ReactNode }) {
  const [formData, setFormData] = useState<TripFormData>({
    dateRange: undefined,
    budget: 500,
    transport: null,
    ambiance: null,
  });
  
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);

  return (
    <TripContext.Provider value={{ formData, setFormData, selectedDestination, setSelectedDestination }}>
      {children}
    </TripContext.Provider>
  );
}

export function useTrip() {
  const context = useContext(TripContext);
  if (context === undefined) {
    throw new Error("useTrip must be used within a TripProvider");
  }
  return context;
}